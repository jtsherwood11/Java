import java.sql.*;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class DB extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet DB</title>");
            out.println("</head>");
            out.println("<body>");

            response.setContentType("text/html");
            out.println("<title>Test Grades</title>" + "<body bgcolor=#F7F7F7>");
            String DATA = request.getParameter("DATA");
            try {
                Class.forName("com.mysql.jdbc.Driver");
            } catch (ClassNotFoundException ex) {
            }

            Connection conn;
            Statement stmt;
            String[] the_return = {"No name", "No year", "No grade"};
            try {
                conn = DriverManager.getConnection("jdbc:mysql://localhost/cs4010", "cs4010", "cs4010");
                stmt = conn.createStatement();
                String[] sql = new String[3];
                ResultSet rs = stmt.executeQuery("select * from student where name="+"'"+DATA+"'");
                while (rs.next()) {
                    the_return[0] = rs.getString("name");
                    the_return[1] = rs.getString("year");
                    the_return[2] = Integer.toString(rs.getInt("test"));
                }
                out.println("<strong>Name:</strong> " + the_return[0] +"<strong> Year:</strong> "+the_return[1]+" <strong>Grade:</strong> "+the_return[2]);
            } catch (SQLException se) {
            }

            out.println("</body>");
            out.println("</html>");
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
    }
}

