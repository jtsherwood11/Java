The DB folder contains a student.html file that calls
the servlet that connects to the cs4010 SQL Database
and returns the students grade.



 
