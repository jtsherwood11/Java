<?php
$con=mysqli_connect("dan2013.db.8742284.hostedresource.com","dan2013","Danwashere13!","dan2013");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }

   $punique = mysqli_real_escape_string($con,$_POST['punique']);
   
$result = mysqli_query($con,"SELECT * FROM Persons");

echo "<table id='resulttable' border='1'>";
echo "<tr><td>Entry #</td><td>First Name</td><td>Last Name</td><td>Phone Number</td><td><b>EDIT</b></td><td><b>DELETE</b></td><tr>";
while($row = mysqli_fetch_array($result))
  {
  if($row['PID']== $punique)
  {
    echo "<tr><td>" . htmlspecialchars($row['PID']) . "</td><td><input type='text' name='fname1' id='fname1' onblur='subcheck(fname1.value,lname1.value,pnum1.value);' value='". htmlspecialchars($row['FirstName'])."'><div id='error4'></div></td><td><input type='text' name='lname1' id='lname1' onblur='subcheck(fname1.value,lname1.value,pnum1.value);' value='".htmlspecialchars($row['LastName'])."'><div id='error5'></div></td><td><input type='text' name='pnum1' id='pnum1' onblur='subcheck(fname1.value,lname1.value,pnum1.value);' value='". htmlspecialchars($row['PhoneNumber']) ."'><div id='error6'></div></td><td colspan='2'><input type='submit' name='Subedit' id='subEdit' value='Confirm Edit' disabled='true' onclick='subedit(fname1.value,lname1.value,pnum1.value,". $row['PID'] .")'><input type='submit' name='editCancel' id='editCancel' value='Cancel' onclick='display();'></td></tr>";  //$row['index'] the index here is a field name
  }
  else
  {
  echo "<tr><td>" . htmlspecialchars($row['PID']) . "</td><td>" . htmlspecialchars($row['FirstName']) . "</td><td>" . htmlspecialchars($row['LastName']) . "</td><td>(" . substr(htmlspecialchars($row['PhoneNumber']), 0, 3) .")-". substr(htmlspecialchars($row['PhoneNumber']), 3, 3)."-" . substr(htmlspecialchars($row['PhoneNumber']), 6, 4). "</td><td><input type='submit' name='Edit' id='Edit' value='Edit' onclick='edit(". $row['PID'] .");'></td><td><input type='submit' name='-' id='-' value='-' onclick='delentry(". $row['PID'] .");'></td></tr>";  //$row['index'] the index here is a field name
  }
  }
echo "</table>";

mysqli_close($con);
?>