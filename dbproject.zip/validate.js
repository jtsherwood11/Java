function clearFields(){
document.getElementById("fname").value = "";
document.getElementById("lname").value = "";
document.getElementById("pnum").value = "";
document.getElementById("sinput").value = "";
}


function subcheck(f,l,p) {
fn = f;
ln = l;
pn = p;
	var valid = 0;
  var fvalid = (fn.match(/^([^0-9]*)$/));
  if (fvalid) {
    document.getElementById("fname1").style.backgroundColor="white";
    document.getElementById("error4").innerText = "";
    valid++;
  } else {
    document.getElementById("fname1").style.backgroundColor="yellow";
	document.getElementById("error4").innerText = "Number Detected";
    valid--;
  }
  
  var lvalid = (ln.match(/^([^0-9]*)$/));
  if (lvalid) {
    document.getElementById("lname1").style.backgroundColor="white";
    document.getElementById("error5").innerText = "";
    valid++;
  } else {
    document.getElementById("lname1").style.backgroundColor="yellow";
	document.getElementById("error5").innerText = "Number Detected";
    valid--;
  }
  
    var pvalid = (pn.match(/^\d{10}$/));

  if (pvalid) {
    document.getElementById("pnum1").style.backgroundColor="white";
    document.getElementById("error6").innerText = "";
    valid++;
  } else {
    document.getElementById("pnum1").style.backgroundColor="yellow";
	document.getElementById("error6").innerText = "Not a 10 digit number";
    valid--;
  }
  
  if(valid==3)
  {
      document.getElementById("subEdit").disabled = false;
  }
  else
  {
      document.getElementById("subEdit").disabled = true;
  }
}

function ncheck(f,l,p) {
fn = f;
ln=l;
pn=p;

var tvalid=0;
  var fvalid = (fn.match(/^([^0-9]*)$/));
  if (fvalid) {
    document.getElementById("fname").style.backgroundColor="white";
    document.getElementById("error1").innerText = "";
    tvalid++;
  } else {
    document.getElementById("fname").style.backgroundColor="yellow";
	document.getElementById("error1").innerText = "Number Detected";
    tvalid--;
  }
  
  var lvalid = (ln.match(/^([^0-9]*)$/));
  if (lvalid) {
    document.getElementById("lname").style.backgroundColor="white";
    document.getElementById("error2").innerText = "";
    tvalid++;
  } else {
    document.getElementById("lname").style.backgroundColor="yellow";
	document.getElementById("error2").innerText = "Number Detected";
    tvalid--;
  }
  
  var pvalid = (pn.match(/^\d{10}$/));
  if (pvalid) {
    document.getElementById("pnum").style.backgroundColor="white";
    document.getElementById("error3").innerText = "";
    tvalid++;
  } else {
    document.getElementById("pnum").style.backgroundColor="yellow";
	document.getElementById("error3").innerText = "Not a 10 digit number";
    tvalid--;
  }
  
  if(tvalid==3)
  {
  document.getElementById("+").disabled = false;
  }
  else{
  document.getElementById("+").disabled = true;
  }
}
