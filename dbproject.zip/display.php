<?php

$con=mysqli_connect("dan2013.db.8742284.hostedresource.com","dan2013","Danwashere13!","dan2013");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  echo "<table id='resulttable' border='1'><tr><td>Entry #</td><td>First Name</td><td>Last Name</td><td>Phone Number</td><td><b>EDIT</b></td><td><b>DELETE</b></td><tr>";
$result = mysqli_query($con,"SELECT * FROM Persons");
while($row = mysqli_fetch_array($result))
  {
  echo "<tr><td>" . htmlspecialchars($row['PID']) . "</td><td>" . htmlspecialchars($row['FirstName']) . "</td><td>" . htmlspecialchars($row['LastName']) . "</td><td>(" . substr(htmlspecialchars($row['PhoneNumber']), 0, 3) .")-". substr(htmlspecialchars($row['PhoneNumber']), 3, 3)."-" . substr(htmlspecialchars($row['PhoneNumber']), 6, 4). "</td><td><input type='submit' name='Edit' id='Edit' value='Edit' onclick='edit(". $row['PID'] .");'></td><td><input type='submit' name='-' id='-' value='-' onclick='delentry(". $row['PID'] .");'></td></tr>";  //$row['index'] the index here is a field name
  
  }
echo "</table>";
mysqli_close($con);
?>
