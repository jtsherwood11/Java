

<?php
$con=mysqli_connect("dan2013.db.8742284.hostedresource.com","dan2013","Danwashere13!","dan2013");
// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
  
  $fname = mysqli_real_escape_string($con,$_POST['fname1']);
  $lname = mysqli_real_escape_string($con,$_POST["lname1"]);
  $pnum = mysqli_real_escape_string($con,$_POST["pnum1"]);
  $punique = mysqli_real_escape_string($con,$_POST['punique']);

$validation = 0;

if (preg_match("/^([^0-9]*)$/", $fname)) {
    $validation++;
	}
	
if (preg_match("/^([^0-9]*)$/", $lname)) {
    $validation++;
	}

if (preg_match("/^\d{10}$/", $pnum)) {
    $validation++;
	}
	
	if ($validation == 3){
	 
  $sql="UPDATE Persons
SET FirstName='$fname', LastName='$lname', PhoneNumber='$pnum'
WHERE PID='$punique'";

if (!mysqli_query($con,$sql))
  {
  die('Error: ' . mysqli_error($con));
  }
echo "1 record modified";

$result = mysqli_query($con,"SELECT * FROM Persons");

echo "<table id='resulttable' border='1'>";
echo "<tr><td>Entry #</td><td>First Name</td><td>Last Name</td><td>Phone Number</td><td><b>EDIT</b></td><td><b>DELETE</b></td><tr>";
while($row = mysqli_fetch_array($result))
  {
  echo "<tr><td>" . htmlspecialchars($row['PID']) . "</td><td>" . htmlspecialchars($row['FirstName']) . "</td><td>" . htmlspecialchars($row['LastName']) . "</td><td>(" . substr(htmlspecialchars($row['PhoneNumber']), 0, 3) .")-". substr(htmlspecialchars($row['PhoneNumber']), 3, 3)."-" . substr(htmlspecialchars($row['PhoneNumber']), 6, 4). "</td><td><input type='submit' name='Edit' id='Edit' value='Edit' onclick='edit(". $row['PID'] .");'></td><td><input type='submit' name='-' id='-' value='-' onclick='delentry(". $row['PID'] .");'></td></tr>";  //$row['index'] the index here is a field name
  }
echo "</table>";
}
mysqli_close($con);
?>